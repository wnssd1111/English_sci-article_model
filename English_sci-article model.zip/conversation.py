import os
import json
import re
from pathlib import Path

import tkinter as tk
from tkinter import messagebox, ttk
from tkinter import font as tkfont

from openai import OpenAI

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# ================== 기본 설정 ==================

MODEL_NAME = "gpt-4.1-mini"
MEMORY_FILE = Path("english_chat_memory.json")
EXP_FILE_CSV = Path("expressions_history.csv")

BG_MAIN = "#020617"    # 전체 배경
BG_CHAT = "#020617"
COLOR_USER = "#4f46e5"  # 사용자 버블
COLOR_AI = "#1f2937"    # AI 버블
FG_TEXT = "white"

MAX_HISTORY_ANALYSES = 7

client = OpenAI()  # OPENAI_API_KEY 환경변수 필요

# 전역 상태
messages = []
analysis_history = []      # [{grammar,naturalness,variety,explain_en,explain_ko}, ...]
expressions_history = []   # [{user, buddy}, ...]
analysis_window = None
analysis_canvas = None
analysis_text_widget = None

last_user_for_analysis = None
last_analysis_text = None

# 최근 일반 대화용
last_user_message = None
last_assistant_message = None

phrases_window = None

# 모든 채팅 버블 Label 모아두는 리스트 (리사이즈시 wraplength 재설정용)
bubble_labels = []

# 폰트 드래그 상태
font_drag_start_y = None


# ================== Tk 생성 및 폰트 설정 ==================

root = tk.Tk()  # 폰트 만들려면 Tk가 먼저 있어야 함

FONT_HEADER = tkfont.Font(family="Segoe UI", size=16, weight="bold")
FONT_CHAT = tkfont.Font(family="Segoe UI", size=11)
FONT_NAME = tkfont.Font(family="Segoe UI", size=9, weight="bold")
FONT_ENTRY = tkfont.Font(family="Segoe UI", size=11)
FONT_ANALYSIS = tkfont.Font(family="Segoe UI", size=10)
FONT_TREE = tkfont.Font(family="Segoe UI", size=10)


def change_font_size(delta: int):
    """폰트 크기 전체 변경"""
    for f in (FONT_HEADER, FONT_CHAT, FONT_NAME, FONT_ENTRY, FONT_ANALYSIS, FONT_TREE):
        new_size = max(8, f.cget("size") + delta)
        f.configure(size=new_size)


def start_font_drag(event):
    """Ctrl + 마우스 클릭 시 드래그 시작 위치 저장"""
    global font_drag_start_y
    # Ctrl 눌려있지 않으면 무시
    if not (event.state & 0x0004):  # Control mask
        return
    font_drag_start_y = event.y_root


def on_font_drag(event):
    """Ctrl 누른 상태에서 드래그하면서 폰트 크기 조절"""
    global font_drag_start_y
    if font_drag_start_y is None:
        return
    if not (event.state & 0x0004):  # Control 안 누르면 취소
        return

    dy = event.y_root - font_drag_start_y
    step = dy // 10  # 10px 움직일 때마다 1pt 변경
    if step != 0:
        # 위로 드래그(음수)면 글씨 키우기, 아래로 드래그면 줄이기
        change_font_size(-step)
        font_drag_start_y = event.y_root


def end_font_drag(event):
    """드래그 종료"""
    global font_drag_start_y
    font_drag_start_y = None


# 모든 윈도우에 대해 Ctrl+드래그 바인드
root.bind_all("<Button-1>", start_font_drag)
root.bind_all("<B1-Motion>", on_font_drag)
root.bind_all("<ButtonRelease-1>", end_font_drag)


# ================== 메모리 로드/세이브 ==================

def load_memory():
    global messages, analysis_history, expressions_history
    if MEMORY_FILE.exists():
        try:
            data = json.load(MEMORY_FILE.open("r", encoding="utf-8"))
            messages = data.get("messages", [])
            analysis_history = data.get("analysis_history", [])
            expressions_history = data.get("expressions_history", [])
        except Exception:
            messages = []
            analysis_history = []
            expressions_history = []

    if not messages:
        messages.append({
            "role": "system",
            "content": (
                "You are a friendly English conversation partner for a Korean neuroscience graduate student. "
                "Speak in natural, casual, spoken English (like a kind friend). "
                "Sometimes, refer back to previous chats: ask about their research projects, tasks, "
                "or hobbies you saw before, like 'How is your project going these days?' "
                "If they mentioned favorite food or interests before, you can occasionally remember them. "
                "Keep answers relatively short. "
                "If their English is a bit unnatural, respond normally first, "
                "then add a short 'Better expression:' line with 1–2 improved versions."
            ),
        })


def save_memory():
    data = {
        "messages": messages,
        "analysis_history": analysis_history,
        "expressions_history": expressions_history,
    }
    try:
        MEMORY_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print("메모리 저장 실패:", e)


# ================== GPT 호출 ==================

def ask_gpt(user_text: str) -> str:
    """일반 대화용 GPT 호출"""
    global last_user_message, last_assistant_message
    messages.append({"role": "user", "content": user_text})
    last_user_message = user_text

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=messages,
        temperature=0.7,
    )

    reply = response.choices[0].message.content.strip()
    messages.append({"role": "assistant", "content": reply})
    last_assistant_message = reply
    return reply


def analyze_sentence_with_gpt(sentence: str) -> str:
    """마지막 사용자 문장 분석용 GPT 호출 (별도 프롬프트 사용)"""
    system_prompt = (
        "You are an English teacher. Analyze the student's last sentence.\n"
        "Rate it on a 0–100 scale for each item:\n"
        "1) Grammar accuracy (문법 정확도)\n"
        "2) Naturalness in real conversation (대화 자연스러움)\n"
        "3) Variety and richness of expressions (표현의 다양성)\n\n"
        "Then:\n"
        "- Briefly explain the main problems in English.\n"
        "- Provide 1–3 improved example sentences.\n"
        "- Finally, give a short summary in Korean about how good the sentence is overall.\n"
        "Answer in this format:\n"
        "Grammar: xx/100\n"
        "Naturalness: xx/100\n"
        "Expression variety: xx/100\n\n"
        "Explanation:\n"
        "... \n\n"
        "Better examples:\n"
        "- ...\n"
        "- ...\n\n"
        "Korean summary:\n"
        "..."
    )

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": sentence},
        ],
        temperature=0.4,
    )

    analysis_text = response.choices[0].message.content.strip()
    return analysis_text


# ================== 분석 텍스트 파싱 ==================

def parse_scores(analysis_text: str):
    """ 'Grammar: 80/100' 같은 줄에서 점수 정수로 뽑기 """
    grammar = natural = variety = None
    for line in analysis_text.splitlines():
        line = line.strip()
        m = re.match(r"Grammar:\s*(\d+)", line, re.I)
        if m:
            grammar = int(m.group(1))
        m = re.match(r"Naturalness:\s*(\d+)", line, re.I)
        if m:
            natural = int(m.group(1))
        m = re.match(r"Expression\s+variety:\s*(\d+)", line, re.I)
        if m:
            variety = int(m.group(1))
    return grammar, natural, variety


def parse_explanations(analysis_text: str):
    """ Explanation / Korean summary 부분 분리 """
    explain_en = ""
    explain_ko = ""

    m = re.search(r"Explanation:\s*(.*?)(?:\n\s*Better examples:|\Z)", analysis_text, re.S | re.I)
    if m:
        explain_en = m.group(1).strip()

    m = re.search(r"Korean summary:\s*(.*)", analysis_text, re.S | re.I)
    if m:
        explain_ko = m.group(1).strip()

    return explain_en, explain_ko


def parse_best_example(analysis_text: str):
    """Better expression(s) 섹션에서 첫 번째 예문 추출"""
    # 'Better expression:' 또는 'Better examples:' 모두 허용
    m = re.search(r"Better expression[s]?:\s*(.*)", analysis_text, re.I | re.S)
    if not m:
        return None

    block = m.group(1).strip()
    # 첫 번째 줄 중 '- ' 로 시작하는 문장 찾기
    for line in block.splitlines():
        line = line.strip()
        if line.startswith("-"):
            return line[1:].strip()
        if line:  # 비어있지 않은 첫 줄이면 그것도 허용
            return line
    return None


# ================== Tkinter 메인 윈도우 설정 ==================

root.title("English Chat with GPT")
root.geometry("700x720")
root.configure(bg=BG_MAIN)

root.grid_columnconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=1)

# ----- 상단 헤더 -----
header = tk.Label(
    root,
    text="English Chat",
    bg="#020617",
    fg="white",
    font=FONT_HEADER,
    pady=10,
)
header.grid(row=0, column=0, sticky="ew")

# ----- 채팅 영역 -----
chat_frame = tk.Frame(root, bg=BG_CHAT)
chat_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)

canvas = tk.Canvas(chat_frame, bg=BG_CHAT, highlightthickness=0)
scrollbar = tk.Scrollbar(chat_frame, orient="vertical", command=canvas.yview)
scrollable_frame = tk.Frame(canvas, bg=BG_CHAT)

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")


def _on_mousewheel(event):
    canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


canvas.bind_all("<MouseWheel>", _on_mousewheel)

# ----- 하단 입력/버튼 -----
bottom_frame = tk.Frame(root, bg=BG_MAIN)
bottom_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
for i in range(5):
    bottom_frame.grid_columnconfigure(i, weight=0)
bottom_frame.grid_columnconfigure(0, weight=1)

entry = tk.Entry(bottom_frame, font=FONT_ENTRY)
entry.grid(row=0, column=0, columnspan=4, sticky="ew", padx=(0, 5), pady=(0, 5))

send_button = tk.Button(bottom_frame, text="Send", width=7, command=lambda: send_message())
send_button.grid(row=0, column=4, padx=(0, 0), pady=(0, 5))

analyze_button = tk.Button(bottom_frame, text="Analyze", width=8, command=lambda: analyze_sentence())
analyze_button.grid(row=1, column=1, padx=(0, 5))

save_expr_button = tk.Button(bottom_frame, text="Save Expr", width=8, command=lambda: save_expression_pair())
save_expr_button.grid(row=1, column=2, padx=(0, 5))

phrases_button = tk.Button(bottom_frame, text="Phrases", width=8, command=lambda: open_phrases_window())
phrases_button.grid(row=1, column=3, padx=(0, 5))

clear_button = tk.Button(bottom_frame, text="Clear", width=7, command=lambda: clear_chat())
clear_button.grid(row=1, column=4)


def current_wraplength():
    # 창 가로 크기의 75% 정도를 버블 최대 폭으로 사용
    w = root.winfo_width()
    return max(260, int(w * 0.75))


def add_message_bubble(text: str, sender: str):
    line_frame = tk.Frame(scrollable_frame, bg=BG_CHAT)
    line_frame.pack(fill="x", pady=4, anchor="w")

    if sender == "user":
        side = "e"
        bubble_color = COLOR_USER
        name_color = "#a5b4fc"
        name = "You"
        icon_text = "Y"
        anchor = "e"
    else:
        side = "w"
        bubble_color = COLOR_AI
        name_color = "#f97316"
        name = "Buddy"
        icon_text = "B"
        anchor = "w"

    # 프로필 + 이름
    top_frame = tk.Frame(line_frame, bg=BG_CHAT)
    top_frame.pack(fill="x", padx=5)

    icon = tk.Label(
        top_frame,
        text=icon_text,
        bg="#111827",
        fg="white",
        font=FONT_NAME,
        width=2,
        height=1,
        relief="flat",
    )

    name_label = tk.Label(
        top_frame,
        text=name,
        bg=BG_CHAT,
        fg=name_color,
        font=FONT_NAME,
    )

    if side == "e":
        name_label.pack(side="right", anchor=anchor)
        icon.pack(side="right", padx=(4, 0))
    else:
        icon.pack(side="left", padx=(0, 4))
        name_label.pack(side="left", anchor=anchor)

    # 버블 + 그림자
    bubble_outer = tk.Frame(line_frame, bg=BG_CHAT)
    bubble_outer.pack(fill="x", padx=5)

    shadow = tk.Frame(bubble_outer, bg="#000000")

    bubble = tk.Label(
        bubble_outer,
        text=text,
        bg=bubble_color,
        fg=FG_TEXT,
        font=FONT_CHAT,
        padx=10,
        pady=6,
        wraplength=current_wraplength(),
        justify="left",
        relief="flat",
        bd=0,
    )

    if side == "e":
        shadow.pack(anchor="e", padx=(4, 0))
        bubble.pack(anchor="e")
    else:
        shadow.pack(anchor="w", padx=(0, 4))
        bubble.pack(anchor="w")

    bubble.update_idletasks()
    shadow.configure(width=bubble.winfo_width(), height=bubble.winfo_height())
    shadow.place(in_=bubble, x=2, y=2)

    bubble_labels.append(bubble)  # 리사이즈 시 wraplength 조절용

    root.update_idletasks()
    canvas.yview_moveto(1.0)


def update_bubble_wraplengths(event=None):
    """창 리사이즈 시 모든 버블의 wraplength 갱신"""
    wl = current_wraplength()
    for lbl in bubble_labels:
        lbl.configure(wraplength=wl)


root.bind("<Configure>", update_bubble_wraplengths)


# ================== 분석 창 (그래프 + Buddy 설명) ==================

def open_or_update_analysis_window():
    global analysis_window, analysis_canvas, analysis_text_widget

    if not analysis_history:
        return

    if analysis_window is None or not tk.Toplevel.winfo_exists(analysis_window):
        analysis_window = tk.Toplevel(root)
        analysis_window.title("Progress")
        analysis_window.geometry("820x480")
        analysis_window.configure(bg=BG_MAIN)

        analysis_window.grid_columnconfigure(0, weight=1)
        analysis_window.grid_rowconfigure(0, weight=3)
        analysis_window.grid_rowconfigure(1, weight=2)

        frame_graph = tk.Frame(analysis_window, bg=BG_MAIN)
        frame_graph.grid(row=0, column=0, sticky="nsew")

        fig = Figure(figsize=(8, 3.0), dpi=100, facecolor=BG_MAIN)
        analysis_canvas = FigureCanvasTkAgg(fig, master=frame_graph)
        analysis_canvas.get_tk_widget().pack(fill="both", expand=True)

        analysis_text_widget = tk.Text(
            analysis_window,
            height=6,
            wrap="word",
            font=FONT_ANALYSIS,
            bg=BG_MAIN,
            fg="white",
            borderwidth=0,
        )
        analysis_text_widget.grid(row=1, column=0, sticky="nsew")

    fig = analysis_canvas.figure
    fig.clear()

    ax1 = fig.add_subplot(1, 2, 1, facecolor=BG_MAIN)
    ax2 = fig.add_subplot(1, 2, 2, facecolor=BG_MAIN)

    for ax in (ax1, ax2):
        ax.tick_params(colors="white")
        for spine in ax.spines.values():
            spine.set_color("white")

    idx = list(range(1, len(analysis_history) + 1))
    g_list = [h["grammar"] for h in analysis_history]
    n_list = [h["naturalness"] for h in analysis_history]
    v_list = [h["variety"] for h in analysis_history]

    ax1.plot(idx, g_list, marker="o", label="Grammar")
    ax1.plot(idx, n_list, marker="o", label="Naturalness")
    ax1.plot(idx, v_list, marker="o", label="Expression variety")

    ax1.set_xlabel("Analysis # (recent)", color="white")
    ax1.set_ylabel("Score (0-100)", color="white")
    ax1.set_ylim(0, 100)
    ax1.grid(True, alpha=0.3, color="#4b5563")
    ax1.legend(loc="lower right", fontsize=8, facecolor=BG_MAIN, edgecolor="white")
    ax1.set_title("Progress over last analyses", color="white")

    latest = analysis_history[-1]
    latest_scores = [latest["grammar"], latest["naturalness"], latest["variety"]]
    labels = ["Grammar", "Natural", "Variety"]

    wedges, texts, autotexts = ax2.pie(
        latest_scores,
        labels=labels,
        autopct="%1.1f%%",
        startangle=90,
        textprops={"color": "white"},
    )
    for w in wedges:
        w.set_edgecolor(BG_MAIN)
    ax2.set_title("Latest score ratio", color="white")

    fig.tight_layout()
    analysis_canvas.draw()

    analysis_text_widget.configure(state="normal")
    analysis_text_widget.delete("1.0", tk.END)

    lines = []

    if len(analysis_history) >= 2:
        prev = analysis_history[-2]
        for key, label in [
            ("grammar", "Grammar"),
            ("naturalness", "Naturalness"),
            ("variety", "Expression variety"),
        ]:
            diff = latest[key] - prev[key]
            if diff > 0:
                arrow = "▲"
            elif diff < 0:
                arrow = "▼"
            else:
                arrow = "■"
            lines.append(
                f"{label}: {latest[key]} ({arrow}{abs(diff)} vs last time)"
            )
        lines.append("")

    lines.append("English explanation:")
    lines.append(latest["explain_en"])
    lines.append("")
    lines.append("Korean summary:")
    lines.append(latest["explain_ko"])

    analysis_text_widget.insert("1.0", "\n".join(lines))
    analysis_text_widget.configure(state="disabled")


# ================== 표현 저장/조회 창 ==================

def save_expression_pair():
    """
    Analyze 여부와 상관없이,
    - 최근 user 문장
    - 그 다음 Buddy 답변(가능하면 Better expression의 첫 예문)
    을 한 쌍으로 저장
    """
    if not last_user_message or not last_assistant_message:
        messagebox.showinfo("Info", "먼저 Buddy와 한 번 대화를 나눈 뒤에 저장해 주세요.")
        return

    # Buddy 메시지에서 'Better expression(s)' 찾기
    buddy_expr = parse_best_example(last_assistant_message)
    if buddy_expr is None:
        buddy_expr = last_assistant_message

    expressions_history.append(
        {
            "user": last_user_message,
            "buddy": buddy_expr,
        }
    )
    messagebox.showinfo("Saved", "이 표현 쌍을 저장했어요! (Phrases 버튼에서 확인 가능)")


def open_phrases_window():
    global phrases_window

    if phrases_window is None or not tk.Toplevel.winfo_exists(phrases_window):
        phrases_window = tk.Toplevel(root)
        phrases_window.title("Saved expressions")
        phrases_window.geometry("750x420")
        phrases_window.configure(bg=BG_MAIN)

        phrases_window.grid_columnconfigure(0, weight=1)
        phrases_window.grid_rowconfigure(0, weight=1)

        frame_table = tk.Frame(phrases_window, bg=BG_MAIN)
        frame_table.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        style = ttk.Style()
        style.theme_use("default")
        style.configure(
            "Dark.Treeview",
            background=BG_MAIN,
            fieldbackground=BG_MAIN,
            foreground="white",
            rowheight=24,
        )
        style.configure(
            "Dark.Treeview.Heading",
            background="#111827",
            foreground="white",
        )

        columns = ("you", "buddy")
        tree = ttk.Treeview(
            frame_table, columns=columns, show="headings", height=12,
            style="Dark.Treeview"
        )
        tree.heading("you", text="You expression")
        tree.heading("buddy", text="Buddy expression")
        tree.column("you", width=360)
        tree.column("buddy", width=360)
        tree.pack(fill="both", expand=True)

        vsb = ttk.Scrollbar(frame_table, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        frame_buttons = tk.Frame(phrases_window, bg=BG_MAIN)
        frame_buttons.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        frame_buttons.grid_columnconfigure(0, weight=1)

        delete_btn = tk.Button(frame_buttons, text="Delete selected", width=14,
                               command=lambda: delete_selected_phrase(tree))
        delete_btn.pack(side="right", padx=(0, 5))

        export_btn = tk.Button(frame_buttons, text="Export CSV", width=12,
                               command=lambda: export_expressions_csv())
        export_btn.pack(side="right")

        phrases_window.tree = tree

    # 내용 업데이트
    tree = phrases_window.tree
    for row in tree.get_children():
        tree.delete(row)

    for idx, item in enumerate(expressions_history):
        tree.insert("", "end", iid=str(idx),
                    values=(item["user"], item["buddy"]))


def delete_selected_phrase(tree: ttk.Treeview):
    """선택된 행 삭제"""
    global expressions_history
    selected = tree.selection()
    if not selected:
        messagebox.showinfo("Info", "먼저 삭제할 표현을 선택해 주세요.")
        return

    # 여러 개 선택 가능
    idx_list = sorted([int(iid) for iid in selected], reverse=True)
    for idx in idx_list:
        if 0 <= idx < len(expressions_history):
            expressions_history.pop(idx)

    open_phrases_window()  # 목록 새로고침


def export_expressions_csv():
    if not expressions_history:
        messagebox.showinfo("Info", "저장된 표현이 아직 없습니다.")
        return

    lines = ["you_expression,buddy_expression"]
    for item in expressions_history:
        u = item["user"].replace('"', '""')
        b = item["buddy"].replace('"', '""')
        lines.append(f"\"{u}\",\"{b}\"")

    EXP_FILE_CSV.write_text("\n".join(lines), encoding="utf-8-sig")
    messagebox.showinfo("Exported", f"CSV 파일로 저장했습니다:\n{EXP_FILE_CSV.name}\n(엑셀에서 열 수 있어요)")


# ================== 이벤트 핸들러 ==================

def send_message(event=None):
    user_text = entry.get().strip()
    if not user_text:
        return
    entry.delete(0, tk.END)

    add_message_bubble(user_text, "user")

    try:
        reply = ask_gpt(user_text)
    except Exception as e:
        messagebox.showerror("Error", f"GPT 요청 중 오류가 발생했습니다:\n{e}")
        return

    add_message_bubble(reply, "ai")


def analyze_sentence():
    global last_user_for_analysis, last_analysis_text

    last_user = None    # 마지막 user 문장 찾기
    for msg in reversed(messages):
        if msg["role"] == "user":
            last_user = msg["content"]
            break

    if not last_user:
        messagebox.showinfo("Info", "분석할 사용자 문장이 아직 없습니다.")
        return

    try:
        analysis_text = analyze_sentence_with_gpt(last_user)
    except Exception as e:
        messagebox.showerror("Error", f"분석 중 오류가 발생했습니다:\n{e}")
        return

    last_user_for_analysis = last_user
    last_analysis_text = analysis_text

    add_message_bubble("[Analysis]\n" + analysis_text, "ai")

    g, n, v = parse_scores(analysis_text)
    explain_en, explain_ko = parse_explanations(analysis_text)

    if g is None or n is None or v is None:
        return

    analysis_history.append(
        {
            "grammar": g,
            "naturalness": n,
            "variety": v,
            "explain_en": explain_en,
            "explain_ko": explain_ko,
        }
    )
    if len(analysis_history) > MAX_HISTORY_ANALYSES:
        analysis_history[:] = analysis_history[-MAX_HISTORY_ANALYSES:]

    open_or_update_analysis_window()


def clear_chat():
    global messages, analysis_history, expressions_history, bubble_labels
    for widget in scrollable_frame.winfo_children():
        widget.destroy()
    bubble_labels = []

    messages = []
    analysis_history = []
    expressions_history = []
    load_memory()
    add_message_bubble("New chat started. Say hi! 👋", "ai")


def on_close():
    save_memory()
    root.destroy()


# ================== 초기화 및 시작 ==================

load_memory()

if len(messages) > 1:
    add_message_bubble("Welcome back! I remember our previous talks 😊", "ai")
else:
    add_message_bubble("Hey! Let's practice English together 😊", "ai")

entry.bind("<Return>", send_message)
entry.focus_set()

root.protocol("WM_DELETE_WINDOW", on_close)

root.mainloop()
