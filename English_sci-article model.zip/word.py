import tkinter as tk
from tkinter import messagebox, ttk
import json
import os
import random
from pathlib import Path
from openai import OpenAI

# ================== 설정 ==================

DB_PATH = Path("vocab_gui_db.json")
PHRASE_CSV_PATH = Path("saved_phrases.csv")

USE_GPT = True
GPT_MODEL = "gpt-4.1-mini"

# 색상 (English Chat 스타일)
BG_MAIN = "#020617"
BG_CARD = "#020617"
BTN_PRIMARY = "#4f46e5"
BTN_PRIMARY_ACTIVE = "#6366f1"
BTN_SECONDARY = "#0ea5e9"
BTN_SECONDARY_ACTIVE = "#0284c7"
FG_TEXT = "#e5e7eb"

# OpenAI 클라이언트
client = None
if USE_GPT:
    api_key = os.environ.get("OPENAI_API_KEY")
    if api_key:
        client = OpenAI(api_key=api_key)
    else:
        print("[경고] OPENAI_API_KEY가 설정되지 않았습니다. GPT 기능은 비활성화됩니다.")
        USE_GPT = False

# ================== seed verbs 100개 ==================

ACADEMIC_VERBS = [
    "analyze", "assess", "investigate", "demonstrate", "indicate",
    "suggest", "examine", "explore", "measure", "compare",
    "evaluate", "estimate", "predict", "summarize", "report",
    "discuss", "illustrate", "describe", "confirm", "identify",
    "control", "increase", "decrease", "enhance", "reduce",
    "affect", "influence", "relate", "correlate", "associate",
    "support", "contradict", "replicate", "validate", "confirm",
    "observe", "record", "collect", "select", "allocate",
    "conduct", "perform", "apply", "develop", "design",
    "propose", "test", "formulate", "implement", "optimize",
    "standardize", "normalize", "randomize", "adjust", "calculate",
    "derive", "approximate", "control", "monitor", "track",
    "map", "model", "simulate", "classify", "categorize",
    "cluster", "separate", "distinguish", "compare", "contrast",
    "interpret", "explain", "clarify", "justify", "support",
    "challenge", "refine", "update", "generalize", "limit",
    "conclude", "highlight", "emphasize", "address", "resolve",
    "control", "normalize", "stabilize", "quantify", "qualify",
]


# ================== DB 로드 / 저장 ==================

def load_db():
    if not DB_PATH.exists():
        return {"words": {}, "saved_items": []}
    try:
        data = json.loads(DB_PATH.read_text(encoding="utf-8"))
        if "words" not in data:
            data["words"] = {}
        if "saved_items" not in data:
            data["saved_items"] = []
        return data
    except Exception:
        return {"words": {}, "saved_items": []}


def save_db(db):
    try:
        DB_PATH.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print("[DB 저장 오류]", e)


def ensure_seed_words(db):
    """seed verbs 100개를 DB에 기본 등록 (definition은 None, 나중에 GPT로 생성)"""
    words = db.get("words", {})
    for w in set(ACADEMIC_VERBS):
        if w not in words:
            words[w] = {
                "definition": None,
                "streak": 0,
                "mastered": False,
                "seen": 0,
            }
    db["words"] = words
    save_db(db)


# ================== GPT 유틸 ==================

def generate_definition_with_gpt(word: str) -> str:
    """
    단어 뜻을 GPT로 생성 (논문/연구 스타일, 한 문장, 20단어 이하)
    """
    if not USE_GPT or client is None:
        return f"A basic definition of '{word}' in scientific writing."

    prompt = f"""
You are an English tutor for scientific writing.

TASK:
Give ONE concise English definition for the word "{word}",
suitable for neuroscience or biology research papers.
One sentence only, under 20 words.

Return ONLY the definition sentence, no extra explanation.
"""

    try:
        resp = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        definition = resp.choices[0].message.content.strip()
        # 줄바꿈 제거
        definition = " ".join(definition.split())
        return definition
    except Exception as e:
        print("[GPT 정의 생성 오류]", e)
        return f"A basic definition of '{word}' used in scientific writing."


def generate_question_with_gpt(word: str, definition: str):
    """
    GPT에게:
    - sentences[4]: 4개의 예문
    - correct_index: 0~3 중 정답 인덱스
    - reasons[4]: 각 문장에 대한 en/ko 이유
    를 JSON으로 받아온다.
    """
    if not USE_GPT or client is None:
        return None

    prompt = f"""
You are an English tutor helping a Korean graduate student in neuroscience.

TARGET WORD: {word}
DEFINITION (English): {definition}

TASK:
1. Create EXACTLY FOUR different English sentences in academic or research context
   (experiments, data, results, figure, methods, etc.).
2. All four sentences MUST use the word "{word}" (inflected forms allowed).
3. Exactly ONE sentence must use the word naturally with the given DEFINITION (this is the CORRECT option).
4. The other three sentences must be wrong or unnatural with respect to that meaning
   (wrong meaning, wrong collocation, or nonsense in context).
5. Sentences must all be clearly different from each other.

Then, for EACH sentence, explain briefly:
- in ENGLISH: why it is correct or incorrect for the given definition
- in KOREAN: a short explanation (1–2 sentences).

OUTPUT:
Return ONLY valid JSON in this exact format (no extra text):

{{
  "sentences": ["sentence 1", "sentence 2", "sentence 3", "sentence 4"],
  "correct_index": 0,
  "reasons": [
    {{"en": "reason in English", "ko": "reason in Korean"}},
    {{"en": "reason in English", "ko": "reason in Korean"}},
    {{"en": "reason in English", "ko": "reason in Korean"}},
    {{"en": "reason in English", "ko": "reason in Korean"}}
  ]
}}
"""

    try:
        resp = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
        )
        content = resp.choices[0].message.content.strip()

        # JSON 부분 추출
        start = content.find("{")
        end = content.rfind("}")
        if start == -1 or end == -1:
            raise ValueError("JSON not found in GPT output")
        json_str = content[start:end + 1]
        data = json.loads(json_str)

        sentences = data.get("sentences", [])
        correct_idx = data.get("correct_index", 0)
        reasons = data.get("reasons", [])

        if len(sentences) != 4 or len(reasons) != 4:
            raise ValueError("Unexpected JSON structure")

        return sentences, int(correct_idx), reasons

    except Exception as e:
        print("[GPT 문제 생성 오류]", e)
        return None


def fallback_question(word: str, definition: str):
    """GPT를 사용할 수 없을 때 간단한 예문 4개 생성 (1개 정답, 3개 엉망)"""
    correct = f"In this study, we {word} the relationship between stress and itch in mice."
    wrong1 = f"The {word} of the animals was very hungry this morning."
    wrong2 = f"We bought a new {word} from the supermarket for dinner."
    wrong3 = f"The weather decided to {word} our experiment schedule in a strange way."

    sentences = [correct, wrong1, wrong2, wrong3]
    random.shuffle(sentences)
    correct_idx = sentences.index(correct)

    reasons = []
    for i, s in enumerate(sentences):
        if i == correct_idx:
            reasons.append({
                "en": "This sentence uses the word in a scientific context consistent with the given definition.",
                "ko": "이 문장은 주어진 정의와 일치하는 과학적 맥락에서 단어를 자연스럽게 사용합니다."
            })
        else:
            reasons.append({
                "en": "This sentence does not fit the given academic meaning of the word or is contextually odd.",
                "ko": "이 문장은 단어를 주어진 학술적 의미와 다르게 사용하거나 문맥상 어색합니다."
            })

    return sentences, correct_idx, reasons


# ================== 메인 앱 클래스 ==================

class VocabQuizApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Academic Verb Trainer")
        self.root.configure(bg=BG_MAIN)
        self.root.geometry("720x640")

        # DB 로드 및 seed 반영
        self.db = load_db()
        ensure_seed_words(self.db)

        # 상태
        self.current_word = None
        self.current_definition = None
        self.current_sentences = []
        self.current_correct_index = None
        self.current_reasons = []
        self.answered = False

        self.correct_count = 0
        self.wrong_count = 0
        self.total_count = 0

        self.saved_items = self.db.get("saved_items", [])

        self.phrases_window = None
        self.phrases_tree = None

        self.build_ui()
        self.next_question()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------- UI ----------

    def build_ui(self):
        # 상단 Buddy 말풍선
        top_chat = tk.Frame(self.root, bg=BG_MAIN)
        top_chat.pack(fill="x", pady=(10, 0))

        buddy_label = tk.Label(
            top_chat,
            text="Buddy: Choose the sentence that best matches the meaning of this word 👇",
            font=("Segoe UI", 11),
            fg=FG_TEXT,
            bg=BG_CARD,
            padx=10,
            pady=8,
            wraplength=680,
            justify="left",
        )
        buddy_label.pack(padx=10, pady=5, anchor="w")

        # 단어 + 뜻
        word_frame = tk.Frame(self.root, bg=BG_MAIN)
        word_frame.pack(fill="x", pady=(10, 10))

        self.word_label = tk.Label(
            word_frame,
            text="Loading...",
            font=("Segoe UI", 28, "bold"),
            fg="#f9fafb",
            bg=BG_MAIN,
        )
        self.word_label.pack(pady=4)

        self.def_label = tk.Label(
            word_frame,
            text="",
            font=("Segoe UI", 12),
            fg="#9ca3af",
            bg=BG_MAIN,
            wraplength=680,
            justify="center",
        )
        self.def_label.pack(pady=(0, 4))

        # 예문 버튼들
        options_frame = tk.Frame(self.root, bg=BG_MAIN)
        options_frame.pack(pady=(5, 10), fill="x")

        self.option_buttons = []
        for i in range(4):
            btn = tk.Button(
                options_frame,
                text=f"Sentence {i+1}",
                font=("Segoe UI", 12),
                bg=BTN_PRIMARY,
                fg="#ffffff",
                activebackground=BTN_PRIMARY_ACTIVE,
                activeforeground="#ffffff",
                relief="flat",
                bd=0,
                width=70,
                wraplength=680,
                justify="left",
                anchor="w",
                command=lambda idx=i: self.on_option_click(idx),
            )
            btn.pack(pady=5, padx=10, fill="x")
            self.option_buttons.append(btn)

        # 피드백 레이블
        self.feedback_label = tk.Label(
            self.root,
            text="",
            font=("Segoe UI", 12),
            fg=FG_TEXT,
            bg=BG_MAIN,
            wraplength=680,
            justify="left",
        )
        self.feedback_label.pack(pady=(5, 5))

        # 버튼들 (Next / Save / Phrases / Add words)
        button_frame = tk.Frame(self.root, bg=BG_MAIN)
        button_frame.pack(pady=(5, 10))

        self.next_button = tk.Button(
            button_frame,
            text="Next question ▶",
            font=("Segoe UI", 11, "bold"),
            bg=BTN_SECONDARY,
            fg="#ffffff",
            activebackground=BTN_SECONDARY_ACTIVE,
            activeforeground="#ffffff",
            relief="flat",
            width=16,
            command=self.next_question,
        )
        self.next_button.pack(side="left", padx=5)

        self.save_button = tk.Button(
            button_frame,
            text="Save phrase",
            font=("Segoe UI", 11),
            bg="#10b981",
            fg="#ffffff",
            activebackground="#059669",
            activeforeground="#ffffff",
            relief="flat",
            width=12,
            command=self.save_current_phrase,
        )
        self.save_button.pack(side="left", padx=5)

        self.phrases_button = tk.Button(
            button_frame,
            text="Phrases",
            font=("Segoe UI", 11),
            bg="#6b7280",
            fg="#ffffff",
            activebackground="#4b5563",
            activeforeground="#ffffff",
            relief="flat",
            width=10,
            command=self.open_phrases_window,
        )
        self.phrases_button.pack(side="left", padx=5)

        self.add_words_button = tk.Button(
            button_frame,
            text="Add Words",
            font=("Segoe UI", 11),
            bg="#f97316",
            fg="#ffffff",
            activebackground="#ea580c",
            activeforeground="#ffffff",
            relief="flat",
            width=11,
            command=self.open_add_words_window,
        )
        self.add_words_button.pack(side="left", padx=5)

        # 통계
        bottom_frame = tk.Frame(self.root, bg=BG_MAIN)
        bottom_frame.pack(fill="x", pady=(0, 10))

        self.correct_label = tk.Label(
            bottom_frame,
            text="O 0",
            font=("Segoe UI", 11, "bold"),
            fg="#22c55e",
            bg=BG_MAIN,
        )
        self.correct_label.pack(side="left", padx=20)

        self.progress_label = tk.Label(
            bottom_frame,
            text="0 questions",
            font=("Segoe UI", 11),
            fg=FG_TEXT,
            bg=BG_MAIN,
        )
        self.progress_label.pack(side="left", padx=20)

        self.wrong_label = tk.Label(
            bottom_frame,
            text="X 0",
            font=("Segoe UI", 11, "bold"),
            fg="#ef4444",
            bg=BG_MAIN,
        )
        self.wrong_label.pack(side="right", padx=20)

    # ---------- 단어 후보 목록 ----------

    def build_candidate_words(self):
        words = set(self.db.get("words", {}).keys())
        # seed verbs도 words 안에 이미 ensure_seed_words로 들어가 있음
        return sorted(words)

    # ---------- 새 문제 출제 ----------

    def next_question(self):
        self.answered = False
        self.feedback_label.config(text="")
        for btn in self.option_buttons:
            btn.config(bg=BTN_PRIMARY, state="normal")

        candidate_words = self.build_candidate_words()
        if not candidate_words:
            messagebox.showinfo("Info", "단어가 없습니다. 먼저 Add Words로 단어를 추가해 주세요.")
            return

        word, definition = self.pick_new_word(candidate_words)
        if word is None:
            messagebox.showinfo("완료", "출제할 단어를 찾지 못했습니다.")
            return

        self.current_word = word
        self.current_definition = definition

        # GPT로 문제 생성
        gpt_result = generate_question_with_gpt(word, definition)
        if gpt_result is None:
            sentences, correct_idx, reasons = fallback_question(word, definition)
        else:
            sentences, correct_idx, reasons = gpt_result

        self.current_sentences = sentences
        self.current_correct_index = correct_idx
        self.current_reasons = reasons

        # UI 업데이트
        self.word_label.config(text=word)
        self.def_label.config(text=f"Meaning: {definition}")
        for i, s in enumerate(sentences):
            self.option_buttons[i].config(text=f"{i+1}. {s}")

        self.update_progress_labels()

    def pick_new_word(self, candidate_words):
        tried = set()
        max_tries = min(len(candidate_words), 200)

        for _ in range(max_tries):
            word = random.choice(candidate_words)
            if word in tried:
                continue
            tried.add(word)

            info = self.db["words"].get(word, {})
            definition = info.get("definition")
            if not definition:
                # GPT로 정의 생성
                definition = generate_definition_with_gpt(word)
                info["definition"] = definition
                info.setdefault("streak", 0)
                info.setdefault("seen", 0)
                info.setdefault("mastered", False)
                self.db["words"][word] = info
                save_db(self.db)

            return word, definition

        return None, None

    # ---------- 정답 처리 ----------

    def on_option_click(self, idx):
        if self.answered:
            return
        if not self.current_sentences:
            return

        self.answered = True
        is_correct = (idx == self.current_correct_index)
        self.total_count += 1

        word_info = self.db["words"].get(self.current_word, {})
        word_info.setdefault("streak", 0)
        word_info.setdefault("seen", 0)
        word_info.setdefault("mastered", False)
        word_info["seen"] += 1

        if is_correct:
            self.correct_count += 1
            word_info["streak"] += 1
            self.feedback_label.config(
                text="Buddy: Nice! That sentence matches the meaning 🎉",
                fg="#22c55e",
            )
        else:
            self.wrong_count += 1
            word_info["streak"] = 0
            self.feedback_label.config(
                text="Buddy: Not quite. Let's see why in the explanation window 👀",
                fg="#f97316",
            )

        if word_info["streak"] >= 3:
            word_info["mastered"] = True

        self.db["words"][self.current_word] = word_info
        save_db(self.db)

        # 버튼 색상
        for i, btn in enumerate(self.option_buttons):
            if i == self.current_correct_index:
                btn.config(bg="#22c55e")
            elif i == idx and not is_correct:
                btn.config(bg="#ef4444")
            btn.config(state="disabled")

        self.update_progress_labels()
        self.show_explanation_window(selected_idx=idx)

    # ---------- 정답/오답 이유 창 ----------

    def show_explanation_window(self, selected_idx: int):
        win = tk.Toplevel(self.root)
        win.title("Why is this the answer?")
        win.configure(bg=BG_MAIN)
        win.geometry("720x420")

        text = tk.Text(
            win,
            bg=BG_MAIN,
            fg=FG_TEXT,
            insertbackground="#ffffff",
            font=("Segoe UI", 11),
            wrap="word",
            borderwidth=0,
        )
        text.pack(fill="both", expand=True, padx=10, pady=10)

        for i, sentence in enumerate(self.current_sentences):
            reason = self.current_reasons[i] if i < len(self.current_reasons) else {"en": "", "ko": ""}
            is_correct = (i == self.current_correct_index)
            is_selected = (i == selected_idx)

            header = f"[{i+1}] "
            if is_correct and is_selected:
                header += "✔ Correct (you chose this)\n"
            elif is_correct:
                header += "✔ Correct\n"
            elif is_selected:
                header += "✖ Incorrect (you chose this)\n"
            else:
                header += "✖ Incorrect\n"

            text.insert("end", header)
            text.insert("end", f"Sentence: {sentence}\n")
            text.insert("end", f"Reason (EN): {reason.get('en', '')}\n")
            text.insert("end", f"Reason (KO): {reason.get('ko', '')}\n\n")

        text.config(state="disabled")

    # ---------- Save phrase ----------

    def save_current_phrase(self):
        if not self.current_word or not self.current_definition:
            messagebox.showinfo("Info", "먼저 문제를 풀어본 뒤에 저장해 주세요.")
            return
        if not self.current_sentences:
            messagebox.showinfo("Info", "현재 저장할 예문이 없습니다.")
            return

        idx = self.current_correct_index or 0
        if idx < 0 or idx >= len(self.current_sentences):
            idx = 0

        sentence = self.current_sentences[idx]
        reason = self.current_reasons[idx] if idx < len(self.current_reasons) else {"en": "", "ko": ""}

        item = {
            "word": self.current_word,
            "meaning": self.current_definition,
            "sentence": sentence,
            "reason_en": reason.get("en", ""),
            "reason_ko": reason.get("ko", ""),
        }
        self.saved_items.append(item)
        self.db["saved_items"] = self.saved_items
        save_db(self.db)

        messagebox.showinfo("Saved", "이 단어와 예문을 Phrases에 저장했어요!")

    # ---------- Phrases 창 ----------

    def open_phrases_window(self):
        if self.phrases_window and tk.Toplevel.winfo_exists(self.phrases_window):
            self.refresh_phrases_tree()
            self.phrases_window.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("Saved phrases")
        win.configure(bg=BG_MAIN)
        win.geometry("820x420")
        self.phrases_window = win

        frame = tk.Frame(win, bg=BG_MAIN)
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        columns = ("word", "meaning", "sentence", "reason")
        tree = ttk.Treeview(frame, columns=columns, show="headings", height=12)
        self.phrases_tree = tree

        # 스타일 (다크)
        style = ttk.Style()
        style.theme_use("default")
        style.configure(
            "Dark.Treeview",
            background=BG_MAIN,
            fieldbackground=BG_MAIN,
            foreground=FG_TEXT,
            rowheight=24,
        )
        style.configure(
            "Dark.Treeview.Heading",
            background="#111827",
            foreground="#e5e7eb",
        )
        tree.configure(style="Dark.Treeview")

        tree.heading("word", text="Word")
        tree.heading("meaning", text="Meaning")
        tree.heading("sentence", text="Sentence")
        tree.heading("reason", text="Reason (EN+KO)")

        tree.column("word", width=110, anchor="w")
        tree.column("meaning", width=200, anchor="w")
        tree.column("sentence", width=320, anchor="w")
        tree.column("reason", width=320, anchor="w")

        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        # 버튼들
        btn_frame = tk.Frame(win, bg=BG_MAIN)
        btn_frame.pack(fill="x", padx=10, pady=(0, 10))

        del_btn = tk.Button(
            btn_frame,
            text="Delete selected",
            font=("Segoe UI", 10),
            bg="#ef4444",
            fg="#ffffff",
            activebackground="#b91c1c",
            activeforeground="#ffffff",
            relief="flat",
            width=16,
            command=self.delete_selected_phrase,
        )
        del_btn.pack(side="right", padx=5)

        export_btn = tk.Button(
            btn_frame,
            text="Export CSV",
            font=("Segoe UI", 10),
            bg="#10b981",
            fg="#ffffff",
            activebackground="#059669",
            activeforeground="#ffffff",
            relief="flat",
            width=12,
            command=self.export_phrases_csv,
        )
        export_btn.pack(side="right", padx=5)

        self.refresh_phrases_tree()

    def refresh_phrases_tree(self):
        if not self.phrases_tree:
            return
        tree = self.phrases_tree

        for row in tree.get_children():
            tree.delete(row)

        for idx, item in enumerate(self.saved_items):
            reason_mix = (item.get("reason_en", "") + " / " +
                          item.get("reason_ko", "")).strip()
            tree.insert(
                "",
                "end",
                iid=str(idx),
                values=(
                    item.get("word", ""),
                    item.get("meaning", "")[:80],
                    item.get("sentence", "")[:120],
                    reason_mix[:120],
                ),
            )

    def delete_selected_phrase(self):
        if not self.phrases_tree:
            return
        sel = self.phrases_tree.selection()
        if not sel:
            messagebox.showinfo("Info", "삭제할 항목을 선택해 주세요.")
            return

        # 여러 개 선택 가능 → 인덱스 역순 삭제
        idx_list = sorted([int(iid) for iid in sel], reverse=True)
        for idx in idx_list:
            if 0 <= idx < len(self.saved_items):
                self.saved_items.pop(idx)

        self.db["saved_items"] = self.saved_items
        save_db(self.db)
        self.refresh_phrases_tree()

    def export_phrases_csv(self):
        if not self.saved_items:
            messagebox.showinfo("Info", "저장된 표현이 아직 없습니다.")
            return

        lines = ["word,meaning,sentence,reason_en,reason_ko"]
        for item in self.saved_items:
            def esc(s: str):
                return s.replace('"', '""')
            w = esc(item.get("word", ""))
            m = esc(item.get("meaning", ""))
            s = esc(item.get("sentence", ""))
            re_en = esc(item.get("reason_en", ""))
            re_ko = esc(item.get("reason_ko", ""))
            lines.append(f"\"{w}\",\"{m}\",\"{s}\",\"{re_en}\",\"{re_ko}\"")

        PHRASE_CSV_PATH.write_text("\n".join(lines), encoding="utf-8-sig")
        messagebox.showinfo(
            "Exported",
            f"CSV 파일로 저장했습니다:\n{PHRASE_CSV_PATH.name}\n(엑셀에서 열 수 있어요)",
        )

    # ---------- Add Words 창 ----------

       # ---------- Add Words 창 ----------

    def open_add_words_window(self):
        win = tk.Toplevel(self.root)
        win.title("Add new words")
        win.configure(bg=BG_MAIN)
        win.geometry("480x360")

        label = tk.Label(
            win,
            text=(
                "추가할 영어 단어를 한 줄에 하나씩 적어주세요.\n"
                "예:\n"
                "oxytocin\n"
                "inhibit\n"
                "behavioral\n\n"
                "동사, 형용사, 명사 모두 가능해요.\n"
                "👉 Ctrl + Enter 를 누르면 바로 저장됩니다."
            ),
            font=("Segoe UI", 10),
            fg=FG_TEXT,
            bg=BG_MAIN,
            justify="left",
            wraplength=440,
        )
        label.pack(padx=10, pady=10, anchor="w")

        text = tk.Text(
            win,
            bg="#020617",
            fg=FG_TEXT,
            insertbackground="#ffffff",
            font=("Segoe UI", 11),
            height=10,
            borderwidth=0,
        )
        text.pack(padx=10, pady=5, fill="both", expand=True)

        # 🔹 Ctrl+Enter 로 바로 저장되도록 바인딩
        def on_ctrl_enter(event):
            self.add_words_from_text(text.get("1.0", "end").strip())
            return "break"

        text.bind("<Control-Return>", on_ctrl_enter)

        btn = tk.Button(
            win,
            text="Add to bank",
            font=("Segoe UI", 10, "bold"),
            bg="#22c55e",
            fg="#ffffff",
            activebackground="#16a34a",
            activeforeground="#ffffff",
            relief="flat",
            width=14,
            command=lambda: self.add_words_from_text(text.get("1.0", "end").strip()),
        )
        btn.pack(pady=10)

    def add_words_from_text(self, text: str):
        if not text:
            messagebox.showinfo("Info", "추가할 단어를 입력해 주세요.")
            return

        lines = [l.strip() for l in text.splitlines()]
        lines = [l for l in lines if l]
        if not lines:
            messagebox.showinfo("Info", "단어가 감지되지 않았습니다.")
            return

        words_db = self.db.get("words", {})
        added = 0

        for w in lines:
            if w not in words_db:
                words_db[w] = {
                    "definition": None,
                    "streak": 0,
                    "mastered": False,
                    "seen": 0,
                }
                added += 1

        self.db["words"] = words_db
        save_db(self.db)

        messagebox.showinfo("Added", f"{added}개의 새로운 단어를 데이터 뱅크에 추가했습니다.")

    # ---------- 기타 ----------

    def update_progress_labels(self):
        self.correct_label.config(text=f"O {self.correct_count}")
        self.wrong_label.config(text=f"X {self.wrong_count}")
        self.progress_label.config(text=f"{self.total_count} questions")

    def on_close(self):
        self.db["saved_items"] = self.saved_items
        save_db(self.db)
        self.root.destroy()


    def add_words_from_text(self, text: str):
        if not text:
            messagebox.showinfo("Info", "추가할 단어를 입력해 주세요.")
            return

        lines = [l.strip() for l in text.splitlines()]
        lines = [l for l in lines if l]
        if not lines:
            messagebox.showinfo("Info", "단어가 감지되지 않았습니다.")
            return

        words_db = self.db.get("words", {})
        added = 0

        for w in lines:
            # 공백, 숫자 포함 등은 그대로 저장 (나중에 필터링해도 됨)
            if w not in words_db:
                words_db[w] = {
                    "definition": None,
                    "streak": 0,
                    "mastered": False,
                    "seen": 0,
                }
                added += 1

        self.db["words"] = words_db
        save_db(self.db)

        messagebox.showinfo("Added", f"{added}개의 새로운 단어를 데이터 뱅크에 추가했습니다.")

    # ---------- 기타 ----------

    def update_progress_labels(self):
        self.correct_label.config(text=f"O {self.correct_count}")
        self.wrong_label.config(text=f"X {self.wrong_count}")
        self.progress_label.config(text=f"{self.total_count} questions")

    def on_close(self):
        self.db["saved_items"] = self.saved_items
        save_db(self.db)
        self.root.destroy()


# ================== 실행 ==================

if __name__ == "__main__":
    root = tk.Tk()
    app = VocabQuizApp(root)
    root.mainloop()
